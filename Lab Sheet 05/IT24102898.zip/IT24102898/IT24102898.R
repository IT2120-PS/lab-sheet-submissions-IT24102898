setwd("C:/Users/BuyMore/Desktop/New folder (2)/")

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")


names(Delivery_Times)<-c("X1")

attach(Delivery_Times)




histogram<-hist(X1,main="Histogram for Deliver time",breaks=seq(20,70,length=10),right=FALSE)

breaks<-round(histogram$breaks)
freq<-histogram$counts

cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i == 1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

plot(breaks,new,type='l',main="cumulative frequency polygon for Deliver Time",xlab = "Delivery Time",ylab = "Cumulative Frequency",ylim = c(0,max(cum.freq)))
